import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import { SEAT_META } from '@/lib/game/board';
import { GameSession } from '@/lib/game/session';
import type { SessionSnapshot } from '@/lib/game/session';
import type { GameConfig, GameState } from '@/lib/game/types';
import { loadStats, recordResult, resetStats } from '@/lib/game/stats';
import type { WinStats } from '@/lib/game/stats';
import { Board } from '@/components/Board';
import { ControlBar } from '@/components/ControlBar';
import { ReplayBar } from '@/components/ReplayBar';
import { PlayerCard } from '@/components/PlayerCard';
import { AiPanel } from '@/components/AiPanel';
import { EventLog } from '@/components/EventLog';
import { StatsPanel } from '@/components/StatsPanel';
import { Dice } from '@/components/Dice';

interface GameStageProps {
  config: GameConfig;
  onExit: () => void;
}

/** 生成当前阶段的中文提示 */
function describePhase(snap: SessionSnapshot): string {
  const seat = snap.state.seats[snap.actingPlayer];
  const name = seat === undefined ? '玩家' : SEAT_META[seat].name;
  switch (snap.phase) {
    case 'rolling':
      return `${name} 掷骰`;
    case 'thinking':
      return `${name} 推演最优走法`;
    case 'moving':
      return `${name} 移动飞机`;
    case 'settling':
      return `${name} 回合结算`;
    case 'finished':
      return '本局结束';
    default:
      return `${name} 回合`;
  }
}

/** 对局主界面：棋盘、玩家面板、AI 决策、事件日志与回放 */
export function GameStage({ config, onExit }: GameStageProps) {
  const session = useMemo(() => new GameSession(config), [config]);
  const snap = useSyncExternalStore(session.subscribe, session.getSnapshot, session.getSnapshot);

  const [stats, setStats] = useState<WinStats>(() => loadStats());
  const recordedRef = useRef(false);

  useEffect(() => {
    session.start();
    return () => session.dispose();
  }, [session]);

  /** 每局结束写入一次累计统计 */
  useEffect(() => {
    if (snap.status !== 'finished' || recordedRef.current) return;
    recordedRef.current = true;
    setStats(recordResult(snap.state.winner, snap.state.rolls));
  }, [snap.status, snap.state.winner, snap.state.rolls]);

  const replaying = snap.replayIndex !== null;
  const frame = snap.replayIndex === null ? null : snap.frames[snap.replayIndex];
  const viewState: GameState = frame
    ? { ...snap.state, planes: frame.planes, current: frame.current }
    : snap.state;

  /** 回放时展示的是历史帧，因此不显示行动高亮 */
  const activePlayer = replaying ? null : snap.actingPlayer;
  const activePlane =
    playbackPlane(replaying, snap.actingPlayer, snap.activePlane);

  const winnerSeat = snap.state.winner;
  const winnerMeta = winnerSeat === null ? null : SEAT_META[winnerSeat];
  const diceValue = frame ? frame.dice : (snap.dice?.value ?? null);
  const dicePlayer = frame ? frame.current : (snap.dice?.player ?? null);
  const diceKey = frame ? frame.index : (snap.dice?.seq ?? 0);

  /** 重开：清空本局记账标记并重新开始 */
  const handleRestart = () => {
    recordedRef.current = false;
    session.restart();
  };

  return (
    <div className="game-layout">
      <div className="col-left">
        <div className="flex flex-col gap-2.5">
          {snap.state.seats.map((seat, player) => (
            <PlayerCard
              key={seat}
              state={viewState}
              player={player}
              active={!replaying && snap.actingPlayer === player && snap.status !== 'finished'}
              winner={winnerSeat === seat}
            />
          ))}
        </div>
        <StatsPanel seats={snap.state.seats} stats={stats} onReset={() => setStats(resetStats())} />
      </div>

      <div className="col-center">
        {winnerMeta ? (
          <div
            className="panel flex items-center justify-between gap-3 px-4 py-3"
            style={{ borderColor: `${winnerMeta.color}66` }}
          >
            <div className="flex items-center gap-2.5">
              <span
                className="h-2.5 w-2.5 rounded-full"
                style={{ background: winnerMeta.color, boxShadow: `0 0 12px ${winnerMeta.color}` }}
              />
              <span className="text-[13px] font-semibold" style={{ color: winnerMeta.color }}>
                {winnerMeta.name} 获胜
              </span>
              <span className="text-[11px] text-[var(--muted)]">
                共 {snap.state.rolls} 手 · 四机归位
              </span>
            </div>
            <span className="text-[10px] tracking-[0.16em] text-[var(--dim)]">MATCH OVER</span>
          </div>
        ) : null}

        <div className="board-card">
          <Board state={viewState} activePlayer={activePlayer} activePlane={activePlane} />
          <div className="board-legend">
            <span className="legend-item">
              <span className="legend-swatch" data-kind="start" aria-hidden="true" />
              起点 · 掷 6 起飞
            </span>
            <span className="legend-item">
              <span className="legend-swatch" data-kind="jump" aria-hidden="true" />
              同色格 · 跳跃 4 格
            </span>
            <span className="legend-item">
              <span className="legend-swatch" data-kind="fly" aria-hidden="true" />
              飞行格 · 飞跃 12 格
            </span>
            <span className="legend-item">
              <span className="legend-swatch" data-kind="home" aria-hidden="true" />
              星标 · 精确归位
            </span>
          </div>
          <div className="board-status">
            <div className="status-main">
              <span className="phase-dot" data-paused={snap.status !== 'running'} />
              <span className="status-strong">
                {replaying ? '回放模式' : describePhase(snap)}
              </span>
              <span>· 第 {viewState.rolls} 手</span>
            </div>
            <Dice
              value={diceValue}
              rollKey={diceKey}
              rolling={!replaying && snap.phase === 'rolling'}
              player={dicePlayer}
            />
          </div>
        </div>

        {replaying && frame ? (
          <ReplayBar
            index={frame.index}
            total={snap.frames.length}
            label={frame.label}
            playing={snap.replayPlaying}
            onIndex={(index) => session.setReplayIndex(index)}
            onTogglePlay={() => session.toggleReplayPlay()}
            onClose={() => session.closeReplay()}
          />
        ) : (
          <ControlBar
            status={snap.status}
            speed={snap.speed}
            phaseLabel={describePhase(snap)}
            replaying={replaying}
            onToggle={() => session.toggle()}
            onStep={() => session.stepOnce()}
            onSpeed={(speed) => session.setSpeed(speed)}
            onRestart={handleRestart}
            onReplay={() => session.openReplay()}
            onExit={onExit}
          />
        )}
      </div>

      <div className="col-right">
        <AiPanel ai={snap.ai} state={snap.state} thinking={snap.phase === 'thinking'} />
        <EventLog log={snap.log} />
      </div>
    </div>
  );
}

/**
 * 计算棋盘上需要高亮的飞机
 *
 * @param replaying 是否处于回放视图
 * @param player 当前行动玩家序号
 * @param plane 正在移动的飞机序号，未移动为 null
 * @returns 高亮目标；回放或无移动时为 null
 */
function playbackPlane(
  replaying: boolean,
  player: number,
  plane: number | null,
): { player: number; plane: number } | null {
  if (replaying || plane === null) return null;
  return { player, plane };
}
