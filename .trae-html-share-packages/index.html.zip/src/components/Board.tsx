import {
  BASE_ORIGINS,
  BASE_SLOTS,
  BOARD_SIZE,
  CELL,
  FINISH_CELLS,
  FLIGHT_OFFSET,
  HOME_LANES,
  SEAT_META,
  START_INDEX,
  TRACK,
  colorOfTrackIndex,
  flightIndex,
  homeAngle,
  toTrackIndex,
  trackAngle,
} from '@/lib/game/board';
import type { Seat, SeatMeta } from '@/lib/game/board';
import { FINISH, TRACK_LAST } from '@/lib/game/types';
import type { GameState } from '@/lib/game/types';

interface BoardProps {
  state: GameState;
  /** 当前行动的玩家序号（用于机库高亮），无则为 null */
  activePlayer: number | null;
  /** 正在移动的飞机（用于脉冲光圈） */
  activePlane: { player: number; plane: number } | null;
}

interface Placement {
  player: number;
  plane: number;
  seat: Seat;
  x: number;
  y: number;
  rotation: number;
}

const START_SET = new Set<number>(START_INDEX);
const FLIGHT_SET = new Set<number>(SEAT_META.map((meta) => flightIndex(meta.seat)));
const BOARD_CENTER = BOARD_SIZE / 2;

/** 飞机剪影：机头朝上，便于按航向旋转 */
const PLANE_PATH =
  'M0 -18 C2.4 -18 3.8 -16.4 3.8 -13.6 L3.8 -5.2 L15 1.6 L15 4.8 L3.8 2 ' +
  'L3.8 8.6 L8 11.4 L8 13.4 L0 11.6 L-8 13.4 L-8 11.4 L-3.8 8.6 L-3.8 2 ' +
  'L-15 4.8 L-15 1.6 L-3.8 -5.2 L-3.8 -13.6 C-3.8 -16.4 -2.4 -18 0 -18 Z';

/** 计算飞机在棋盘上的显示坐标与朝向（叠加同格偏移） */
function buildPlacements(state: GameState): Placement[] {
  const raw: (Placement & { key: string })[] = [];

  state.planes.forEach((row, player) => {
    const seat = state.seats[player];
    row.forEach((pos, plane) => {
      let key: string;
      let x: number;
      let y: number;
      let rotation: number;

      if (pos < 0) {
        const [originRow, originCol] = BASE_ORIGINS[seat];
        const [slotRow, slotCol] = BASE_SLOTS[plane];
        const cellX = originCol + slotCol;
        const cellY = originRow + slotRow;
        x = cellX * CELL;
        y = cellY * CELL;
        rotation = (Math.atan2(7.5 - cellY, 7.5 - cellX) * 180) / Math.PI + 90;
        key = `base-${seat}-${plane}`;
      } else if (pos <= TRACK_LAST) {
        const absolute = toTrackIndex(seat, pos);
        const [row0, col0] = TRACK[absolute];
        x = (col0 + 0.5) * CELL;
        y = (row0 + 0.5) * CELL;
        rotation = trackAngle(absolute) + 90;
        key = `track-${absolute}`;
      } else if (pos < FINISH) {
        const [row0, col0] = HOME_LANES[seat][pos - 52];
        x = (col0 + 0.5) * CELL;
        y = (row0 + 0.5) * CELL;
        rotation = homeAngle(seat, pos) + 90;
        key = `home-${seat}-${pos}`;
      } else {
        const [row0, col0] = FINISH_CELLS[seat];
        x = (col0 + 0.5) * CELL;
        y = (row0 + 0.5) * CELL;
        rotation = (Math.atan2(7.5 - (row0 + 0.5), 7.5 - (col0 + 0.5)) * 180) / Math.PI + 90;
        key = `finish-${seat}`;
      }

      raw.push({ player, plane, seat, x, y, rotation, key });
    });
  });

  // 同格飞机做环形偏移，避免完全重叠
  const counts = new Map<string, number>();
  raw.forEach((item) => counts.set(item.key, (counts.get(item.key) ?? 0) + 1));
  const cursor = new Map<string, number>();

  return raw.map((item) => {
    const total = counts.get(item.key) ?? 1;
    const index = cursor.get(item.key) ?? 0;
    cursor.set(item.key, index + 1);
    if (total <= 1) return item;

    const angle = (Math.PI * 2 * index) / total - Math.PI / 2;
    const radius = (total === 2 ? 0.14 : 0.18) * CELL;
    return {
      ...item,
      x: item.x + Math.cos(angle) * radius,
      y: item.y + Math.sin(angle) * radius,
    };
  });
}

/** 机库：外围停机坪、内缩的机库平台与四个停机位 */
function Hangar({
  meta,
  active,
  basePositions,
}: {
  meta: SeatMeta;
  active: boolean;
  basePositions: number[];
}) {
  const [row, col] = BASE_ORIGINS[meta.seat];
  const x = col * CELL;
  const y = row * CELL;
  const plaza = 6 * CELL;
  // 平台内缩 0.85 格，让外围留出停机坪，视觉上缩小机库、放大地图
  const inset = 0.85 * CELL;
  const px = x + inset;
  const py = y + inset;
  const size = plaza - inset * 2;
  const cx = x + plaza / 2;
  const cy = y + plaza / 2;

  return (
    <g>
      {/* 停机坪底色与网格 */}
      <rect x={x + 6} y={y + 6} width={plaza - 12} height={plaza - 12} rx={24} fill={meta.base} />
      <rect
        x={x + 6}
        y={y + 6}
        width={plaza - 12}
        height={plaza - 12}
        rx={24}
        fill="url(#apron-grid)"
        opacity={0.8}
      />
      {/* 停机坪四角定位标 */}
      {[
        [x + 18, y + 18, 1, 1],
        [x + plaza - 18, y + 18, -1, 1],
        [x + 18, y + plaza - 18, 1, -1],
        [x + plaza - 18, y + plaza - 18, -1, -1],
      ].map(([bx, by, sx, sy]) => (
        <path
          key={`${bx}-${by}`}
          d={`M${bx} ${by + sy * 16} L${bx} ${by} L${bx + sx * 16} ${by}`}
          fill="none"
          stroke={meta.color}
          strokeOpacity={0.3}
          strokeWidth={1.4}
          strokeLinecap="round"
        />
      ))}

      {/* 平台柔光 */}
      <circle cx={cx} cy={cy} r={size * 0.52} fill={meta.color} opacity={active ? 0.16 : 0.07} />

      {/* 机库平台 */}
      <rect
        x={px}
        y={py}
        width={size}
        height={size}
        rx={32}
        style={{ fill: 'var(--board-hangar)' }}
        stroke={meta.color}
        strokeOpacity={active ? 0.85 : 0.42}
        strokeWidth={active ? 2.6 : 1.6}
      />
      <rect
        x={px + 10}
        y={py + 10}
        width={size - 20}
        height={size - 20}
        rx={24}
        fill="none"
        style={{ stroke: 'var(--board-hangar-line)' }}
        strokeDasharray="9 9"
      />

      {/* 屋顶脊线与标识 */}
      <path
        d={`M${cx - 62} ${py + 62} L${cx} ${py + 40} L${cx + 62} ${py + 62}`}
        fill="none"
        stroke={meta.color}
        strokeOpacity={0.22}
        strokeWidth={1.4}
      />
      <text
        x={cx}
        y={py + 31}
        textAnchor="middle"
        fontSize={12}
        letterSpacing={4}
        fill={meta.color}
        opacity={0.9}
      >
        {meta.name}机库
      </text>
      <text
        x={cx}
        y={py + size - 15}
        textAnchor="middle"
        fontSize={8}
        letterSpacing={2.6}
        fill={meta.color}
        opacity={0.5}
      >
        {`HANGAR 0${meta.seat + 1}`}
      </text>

      {/* 四个停机位 */}
      {BASE_SLOTS.map((slot, index) => {
        const padX = (col + slot[1]) * CELL;
        const padY = (row + slot[0]) * CELL;
        const occupied = basePositions[index] !== undefined && basePositions[index] < 0;
        return (
          <g key={`pad-${index}`}>
            <circle
              cx={padX}
              cy={padY}
              r={CELL * 0.36}
              style={{ fill: 'var(--board-pad)' }}
              stroke={meta.color}
              strokeOpacity={occupied ? 0.42 : 0.7}
              strokeWidth={1.4}
            />
            <circle
              cx={padX}
              cy={padY}
              r={CELL * 0.22}
              fill="none"
              stroke={meta.color}
              strokeOpacity={0.28}
              strokeDasharray="3 4"
            />
            {!occupied ? (
              <text
                x={padX}
                y={padY + 4}
                textAnchor="middle"
                fontSize={11}
                fill={meta.color}
                opacity={0.6}
              >
                {index + 1}
              </text>
            ) : null}
          </g>
        );
      })}
    </g>
  );
}

/** 起点格的起飞标记 */
function StartMark({ meta, x, y }: { meta: SeatMeta; x: number; y: number }) {
  return (
    <g transform={`translate(${x + CELL / 2} ${y + CELL / 2})`}>
      <rect
        x={-18}
        y={-18}
        width={36}
        height={36}
        rx={8}
        fill="none"
        stroke={meta.color}
        strokeOpacity={0.55}
        strokeDasharray="5 4"
      />
      <path
        d="M-6 6 L2 -4 L10 6"
        fill="none"
        stroke={meta.color}
        strokeWidth={2.4}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M-6 13 L2 3 L10 13"
        fill="none"
        stroke={meta.color}
        strokeOpacity={0.5}
        strokeWidth={2.4}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </g>
  );
}

/** 飞行格的飞跃标记 */
function FlightMark({ meta, x, y }: { meta: SeatMeta; x: number; y: number }) {
  return (
    <g transform={`translate(${x + CELL / 2} ${y + CELL / 2})`} className="flight-glyph">
      <circle r={15} fill={meta.color} opacity={0.16} />
      <circle r={15} fill="none" stroke={meta.color} strokeOpacity={0.55} strokeDasharray="3 3" />
      <path d="M-8 -5 L3 -9 L0 -1 Z" fill={meta.color} opacity={0.85} />
      <path d="M8 5 L-3 9 L0 1 Z" fill={meta.color} opacity={0.5} />
    </g>
  );
}

/** 同色格的双箭头跳跃水印 */
function JumpMark({ meta, angle, x, y }: { meta: SeatMeta; angle: number; x: number; y: number }) {
  return (
    <g transform={`translate(${x + CELL / 2} ${y + CELL / 2}) rotate(${angle + 90})`} opacity={0.28}>
      <path
        d="M-7 1 L0 -5 L7 1"
        fill="none"
        stroke={meta.color}
        strokeWidth={2.2}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M-7 8 L0 2 L7 8"
        fill="none"
        stroke={meta.color}
        strokeWidth={2.2}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </g>
  );
}

/** 棋盘主渲染：停机坪、机库、跑道、机制标记、航线与飞机 */
export function Board({ state, activePlayer, activePlane }: BoardProps) {
  const placements = buildPlacements(state);
  const activeSeat = activePlayer === null ? null : state.seats[activePlayer];
  const activePlacement = activePlane
    ? placements.find((item) => item.player === activePlane.player && item.plane === activePlane.plane)
    : undefined;

  return (
    <svg
      className="board-svg"
      viewBox={`0 0 ${BOARD_SIZE} ${BOARD_SIZE}`}
      role="img"
      aria-label="自动飞行棋棋盘"
    >
      <defs>
        <radialGradient id="board-bg" cx="50%" cy="42%" r="72%">
          <stop offset="0%" style={{ stopColor: 'var(--board-bg-1)' }} />
          <stop offset="62%" style={{ stopColor: 'var(--board-bg-2)' }} />
          <stop offset="100%" style={{ stopColor: 'var(--board-bg-3)' }} />
        </radialGradient>
        <radialGradient id="center-bg" cx="50%" cy="45%" r="65%">
          <stop offset="0%" stopColor="rgba(56,232,255,0.18)" />
          <stop offset="55%" stopColor="rgba(139,125,255,0.12)" />
          <stop offset="100%" style={{ stopColor: 'var(--board-bg-3)' }} />
        </radialGradient>
        <radialGradient id="hub-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(56,232,255,0.5)" />
          <stop offset="100%" stopColor="rgba(56,232,255,0)" />
        </radialGradient>
        <pattern id="apron-grid" width="30" height="30" patternUnits="userSpaceOnUse">
          <path d="M30 0 H0 V30" fill="none" style={{ stroke: 'var(--board-apron-line)' }} strokeWidth="1" />
        </pattern>
        {SEAT_META.map((meta) => (
          <marker
            key={`arrow-${meta.seat}`}
            id={`flight-arrow-${meta.seat}`}
            viewBox="0 0 10 10"
            refX="7"
            refY="5"
            markerWidth="4.5"
            markerHeight="4.5"
            orient="auto-start-reverse"
          >
            <path d="M0 0 L10 5 L0 10 Z" fill={meta.color} />
          </marker>
        ))}
      </defs>

      <rect width={BOARD_SIZE} height={BOARD_SIZE} rx={28} fill="url(#board-bg)" />
      <rect
        x={1}
        y={1}
        width={BOARD_SIZE - 2}
        height={BOARD_SIZE - 2}
        rx={28}
        fill="none"
        style={{ stroke: 'var(--board-frame)' }}
      />

      {/* 背景轨道装饰 */}
      <circle
        cx={BOARD_CENTER}
        cy={BOARD_CENTER}
        r={360}
        fill="none"
        style={{ stroke: 'var(--board-apron-line)' }}
        strokeDasharray="2 16"
        opacity={0.5}
      />
      <circle
        cx={BOARD_CENTER}
        cy={BOARD_CENTER}
        r={250}
        fill="none"
        style={{ stroke: 'var(--board-apron-line)' }}
        strokeDasharray="2 12"
        opacity={0.4}
      />

      {/* 四角停机坪与机库 */}
      {SEAT_META.map((meta) => {
        const player = state.seats.indexOf(meta.seat);
        const basePositions = player >= 0 ? state.planes[player] : [];
        return (
          <Hangar
            key={`hangar-${meta.seat}`}
            meta={meta}
            active={activeSeat === meta.seat}
            basePositions={basePositions}
          />
        );
      })}

      {/* 环形跑道 */}
      {TRACK.map(([row, col], index) => {
        const seat = colorOfTrackIndex(index);
        const meta = SEAT_META[seat];
        const isStart = START_SET.has(index);
        const isFlight = FLIGHT_SET.has(index);
        const x = col * CELL;
        const y = row * CELL;
        return (
          <g key={`track-${index}`}>
            <rect
              className="board-cell"
              x={x + 4.5}
              y={y + 4.5}
              width={CELL - 9}
              height={CELL - 9}
              rx={9}
              fill={isStart ? meta.soft : meta.base}
              stroke={meta.color}
              strokeOpacity={isStart ? 0.85 : isFlight ? 0.55 : 0.26}
              strokeWidth={isStart ? 2.2 : 1.2}
              strokeDasharray={isFlight ? '5 4' : undefined}
            />
            {isStart ? (
              <StartMark meta={meta} x={x} y={y} />
            ) : isFlight ? (
              <FlightMark meta={meta} x={x} y={y} />
            ) : (
              <JumpMark meta={meta} angle={trackAngle(index)} x={x} y={y} />
            )}
          </g>
        );
      })}

      {/* 终点跑道 */}
      {HOME_LANES.map((lane, seat) =>
        lane.map(([row, col], index) => {
          const meta = SEAT_META[seat as Seat];
          const x = col * CELL;
          const y = row * CELL;
          const angle = homeAngle(seat as Seat, 52 + index);
          return (
            <g key={`home-${seat}-${index}`}>
              <rect
                x={x + 4.5}
                y={y + 4.5}
                width={CELL - 9}
                height={CELL - 9}
                rx={9}
                fill={meta.soft}
                stroke={meta.color}
                strokeOpacity={0.5}
                strokeWidth={1.2}
              />
              <g transform={`translate(${x + CELL / 2} ${y + CELL / 2}) rotate(${angle})`}>
                <line
                  x1={-24}
                  y1={0}
                  x2={24}
                  y2={0}
                  style={{ stroke: 'var(--board-text)' }}
                  strokeOpacity={0.28}
                  strokeDasharray="6 6"
                />
                <path
                  d="M-4 -6 L3 0 L-4 6"
                  fill="none"
                  stroke={meta.color}
                  strokeWidth={1.8}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  opacity={0.7}
                />
              </g>
            </g>
          );
        }),
      )}

      {/* 中央终点核心 */}
      <rect
        x={6 * CELL + 8}
        y={6 * CELL + 8}
        width={3 * CELL - 16}
        height={3 * CELL - 16}
        rx={22}
        fill="url(#center-bg)"
        style={{ stroke: 'var(--board-frame)' }}
      />
      <circle
        cx={BOARD_CENTER}
        cy={BOARD_CENTER}
        r={1.3 * CELL}
        fill="none"
        stroke="rgba(56,232,255,0.3)"
        strokeWidth={1.2}
        strokeDasharray="4 10"
        className="center-ring"
      />
      <circle
        cx={BOARD_CENTER}
        cy={BOARD_CENTER}
        r={1.02 * CELL}
        fill="none"
        stroke="rgba(255,79,216,0.26)"
        strokeWidth={1.2}
        strokeDasharray="3 8"
        className="center-ring center-ring-reverse"
      />
      {/* 四向闸门 */}
      {[
        [0, -1],
        [1, 0],
        [0, 1],
        [-1, 0],
      ].map(([dx, dy]) => {
        const angle = (Math.atan2(-dy, -dx) * 180) / Math.PI;
        return (
          <path
            key={`gate-${dx}-${dy}`}
            d="M-5 -6 L4 0 L-5 6"
            transform={`translate(${BOARD_CENTER + dx * CELL * 0.82} ${
              BOARD_CENTER + dy * CELL * 0.82
            }) rotate(${angle})`}
            fill="none"
            stroke="rgba(139,125,255,0.55)"
            strokeWidth={1.8}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        );
      })}
      <circle cx={BOARD_CENTER} cy={BOARD_CENTER} r={0.52 * CELL} fill="url(#hub-glow)" opacity={0.75} />
      <circle cx={BOARD_CENTER} cy={BOARD_CENTER} r={7} style={{ fill: 'var(--board-core)' }} />
      <text
        x={BOARD_CENTER}
        y={BOARD_CENTER + 30}
        textAnchor="middle"
        fontSize={9}
        letterSpacing={4}
        style={{ fill: 'var(--board-text)' }}
      >
        终点
      </text>

      {/* 四个归位格 */}
      {FINISH_CELLS.map(([row, col], seat) => {
        const meta = SEAT_META[seat as Seat];
        const cx = (col + 0.5) * CELL;
        const cy = (row + 0.5) * CELL;
        return (
          <g key={`finish-${seat}`}>
            <rect
              x={col * CELL + 7}
              y={row * CELL + 7}
              width={CELL - 14}
              height={CELL - 14}
              rx={9}
              fill={meta.soft}
              stroke={meta.color}
              strokeOpacity={0.5}
              strokeWidth={1.2}
            />
            <circle cx={cx} cy={cy} r={17} fill={meta.color} opacity={0.14} />
            <path
              d="M0 -9 L2.6 -2.6 L9 0 L2.6 2.6 L0 9 L-2.6 2.6 L-9 0 L-2.6 -2.6 Z"
              transform={`translate(${cx} ${cy})`}
              fill={meta.color}
              opacity={0.7}
            />
          </g>
        );
      })}

      {/* 飞行航线 */}
      {SEAT_META.map((meta) => {
        const fromIndex = flightIndex(meta.seat);
        const fromCell = TRACK[fromIndex];
        const toCell = TRACK[(fromIndex + FLIGHT_OFFSET) % TRACK.length];
        const x1 = (fromCell[1] + 0.5) * CELL;
        const y1 = (fromCell[0] + 0.5) * CELL;
        const x2 = (toCell[1] + 0.5) * CELL;
        const y2 = (toCell[0] + 0.5) * CELL;
        const dx = x2 - x1;
        const dy = y2 - y1;
        const length = Math.hypot(dx, dy) || 1;
        const cx = (x1 + x2) / 2 - (dy / length) * length * 0.16;
        const cy = (y1 + y2) / 2 + (dx / length) * length * 0.16;
        const active = activeSeat === meta.seat;
        return (
          <path
            key={`arc-${meta.seat}`}
            className="flight-arc"
            d={`M${x1} ${y1} Q${cx} ${cy} ${x2} ${y2}`}
            fill="none"
            stroke={meta.color}
            strokeOpacity={active ? 0.5 : 0.14}
            strokeWidth={active ? 2.4 : 1.4}
            strokeDasharray="7 9"
            strokeLinecap="round"
            markerEnd={`url(#flight-arrow-${meta.seat})`}
          />
        );
      })}

      {/* 行动飞机的高亮光圈 */}
      {activePlacement && (
        <circle
          className="plane-ring"
          cx={activePlacement.x}
          cy={activePlacement.y}
          r={CELL * 0.42}
          fill="none"
          stroke={SEAT_META[activePlacement.seat].color}
          strokeWidth={2}
          opacity={0.85}
        />
      )}

      {/* 飞机 */}
      {placements.map((item) => {
        const meta = SEAT_META[item.seat];
        const isActive =
          activePlane !== null && activePlane.player === item.player && activePlane.plane === item.plane;
        return (
          <g
            key={`plane-${item.player}-${item.plane}`}
            className={isActive ? 'plane plane-active' : 'plane'}
            style={{
              transform: `translate(${item.x}px, ${item.y}px) rotate(${item.rotation}deg)`,
              transformOrigin: '0 0',
              color: meta.color,
            }}
          >
            <ellipse
              cx={0}
              cy={9}
              rx={12}
              ry={4.5}
              style={{ fill: 'var(--board-plane-shadow)' }}
              opacity={0.35}
            />
            <g style={{ filter: `drop-shadow(0 0 ${isActive ? 11 : 5}px ${meta.color})` }}>
              <path
                d={PLANE_PATH}
                fill={meta.color}
                style={{ stroke: 'var(--board-plane-edge)' }}
                strokeWidth={1.2}
                strokeLinejoin="round"
              />
              <path
                d="M0 -16 L0 11"
                style={{ stroke: 'var(--board-plane-shadow)' }}
                strokeWidth={1}
                opacity={0.55}
              />
              <ellipse cx={0} cy={-10.5} rx={1.9} ry={3.4} fill="#fff" opacity={0.8} />
            </g>
          </g>
        );
      })}
    </svg>
  );
}
