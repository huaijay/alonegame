import { colorOfTrackIndex, flightIndex, toTrackIndex } from '../board';
import { FINISH, TRACK_LAST } from '../types';
import type { GameState } from '../types';

/** 局面评估的分项得分，用于 AI 决策解释面板 */
export interface EvaluationBreakdown {
  /** 推进度：离终点越近越高 */
  progress: number;
  /** 安全性：被踩风险的负向修正 */
  safety: number;
  /** 进攻性：可踩到对手的机会 */
  attack: number;
  /** 归位与终点跑道收益 */
  home: number;
  /** 捷径收益：飞行格与同色格潜力 */
  boost: number;
  total: number;
}

/** 机库内飞机视为略微负面，促使 AI 尽早起飞 */
const BASE_PENALTY = 5;
/** 对手得分的折损系数，让 AI 更偏向主动进攻而不是纯粹拖延 */
const RIVAL_WEIGHT = 0.92;

/**
 * 估算 attacker 在 1-6 点内可直接踩中 defender 的期望次数
 *
 * 除直接踩中外，还计入「落在同色格跳跃 +4」与「落在飞行格飞跃 +12」的间接命中，
 * 用小于 1 的权重表示需要额外满足落点颜色条件。
 *
 * @param state 对局状态
 * @param defender 被踩方玩家序号
 * @param attacker 进攻方玩家序号
 * @returns 期望命中次数（含间接路线的小数权重）
 */
function capturePressure(state: GameState, defender: number, attacker: number): number {
  const attackerSeat = state.seats[attacker];
  const defenderSeat = state.seats[defender];
  const flightAbs = flightIndex(attackerSeat);
  let pressure = 0;

  for (const attackerPos of state.planes[attacker]) {
    if (attackerPos < 0 || attackerPos > TRACK_LAST) continue;
    const from = toTrackIndex(attackerSeat, attackerPos);

    for (const defenderPos of state.planes[defender]) {
      if (defenderPos < 0 || defenderPos > TRACK_LAST) continue;
      const distance = (toTrackIndex(defenderSeat, defenderPos) - from + 52) % 52;
      if (distance === 0) continue;

      // 直接命中：本次点数正好落在对手格
      if (distance <= 6 && attackerPos + distance <= TRACK_LAST) {
        pressure += 1;
        continue;
      }

      // 间接命中：先落在同色格，再跳跃 4 格
      const jumpDice = distance - 4;
      if (jumpDice >= 1 && jumpDice <= 6 && attackerPos + distance <= TRACK_LAST) {
        const landing = (from + jumpDice) % 52;
        if (colorOfTrackIndex(landing) === attackerSeat) pressure += 0.65;
      }

      // 间接命中：先落在飞行格，再飞跃 12 格
      const flyDice = distance - 12;
      if (flyDice >= 1 && flyDice <= 6 && attackerPos + distance <= TRACK_LAST) {
        if ((from + flyDice) % 52 === flightAbs) pressure += 0.55;
      }
    }
  }

  return pressure;
}

/**
 * 计算某玩家视角下的完整局面评分
 *
 * @param state 对局状态
 * @param root 评分视角玩家序号
 * @returns 分项得分与总分
 */
export function breakdownOf(state: GameState, root: number): EvaluationBreakdown {
  let progress = 0;
  let home = 0;
  let boost = 0;

  let pressureOnRoot = 0;
  let pressureByRoot = 0;
  for (let p = 0; p < state.seats.length; p += 1) {
    if (p === root) continue;
    pressureOnRoot += capturePressure(state, root, p);
    pressureByRoot += capturePressure(state, p, root);
  }

  for (let p = 0; p < state.seats.length; p += 1) {
    const seat = state.seats[p];
    const weight = p === root ? 1 : -RIVAL_WEIGHT;

    for (const pos of state.planes[p]) {
      if (pos < 0) {
        progress -= BASE_PENALTY * weight;
        continue;
      }
      // 跑道内按已走步数计分；进入终点跑道后继续按步数推进
      progress += (Math.min(pos, FINISH) + 1) * 1.15 * weight;
      if (pos === FINISH) home += 105 * weight;
      else if (pos >= 52) home += 24 * weight;

      if (pos > TRACK_LAST) continue;

      // 距飞行格 1-6 点以内，说明下一次有机会触发 +12
      if (pos >= 6 && pos < 12) boost += 9 * weight;

      // 接下来 1-6 点中能落在同色格的次数，代表跳跃潜力
      let colorHits = 0;
      for (let dice = 1; dice <= 6; dice += 1) {
        const next = pos + dice;
        if (next > TRACK_LAST) break;
        if (colorOfTrackIndex(toTrackIndex(seat, next)) === seat) colorHits += 1;
      }
      boost += colorHits * 1.6 * weight;
    }
  }

  const safety = -21 * pressureOnRoot + 9 * pressureByRoot;
  const attack = 15 * pressureByRoot - 7 * pressureOnRoot;

  return {
    progress,
    safety,
    attack,
    home,
    boost,
    total: progress + safety + attack + home + boost,
  };
}

/**
 * 局面评估函数：从 root 玩家视角给出总分
 *
 * @param state 对局状态
 * @param root 评分视角玩家序号
 * @returns 总分
 */
export function evaluate(state: GameState, root: number): number {
  if (state.winner !== null) {
    return state.winner === state.seats[root] ? 1_000_000 : -1_000_000;
  }
  return breakdownOf(state, root).total;
}
