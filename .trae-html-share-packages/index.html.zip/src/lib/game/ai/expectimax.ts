import { applyMove, getLegalMoves, passTurn } from '../rules';
import type { GameState, Move } from '../types';
import { breakdownOf, evaluate } from './evaluate';
import type { EvaluationBreakdown } from './evaluate';

/** 搜索参数 */
export interface SearchOptions {
  /** 后续掷骰的搜索层数 */
  depth: number;
  /** 时间上限（毫秒），超时后直接使用估值函数 */
  budgetMs: number;
  /** 节点上限，避免低端设备卡顿 */
  nodeBudget: number;
}

/** 单个候选走法的评估结果 */
export interface Candidate {
  move: Move;
  /** Expectimax 期望值 */
  value: number;
  /** 立即结算后的分项评分，用于解释面板 */
  breakdown: EvaluationBreakdown;
}

/** 一次完整决策 */
export interface Decision {
  move: Move;
  value: number;
  /** 候选走法，按期望值降序 */
  candidates: Candidate[];
  nodes: number;
  ms: number;
  depth: number;
}

interface SearchContext {
  root: number;
  nodes: number;
  nodeBudget: number;
  deadline: number;
}

/**
 * Expectimax 搜索：当前玩家为 max 节点，掷骰为 chance 节点
 *
 * @param state 待评估的局面（已包含上一步行动的结果）
 * @param depth 剩余掷骰层数
 * @param ctx 搜索上下文（根玩家、节点预算、截止时间）
 * @returns 从根玩家视角的期望得分
 */
function search(state: GameState, depth: number, ctx: SearchContext): number {
  if (state.winner !== null) return evaluate(state, ctx.root);
  if (depth <= 0 || ctx.nodes >= ctx.nodeBudget || performance.now() > ctx.deadline) {
    ctx.nodes += 1;
    return evaluate(state, ctx.root);
  }

  let total = 0;
  for (let dice = 1; dice <= 6; dice += 1) {
    const moves = getLegalMoves(state, dice);
    if (moves.length === 0) {
      // 无子可动直接跳过回合，不享受掷 6 追加
      total += search(passTurn(state), depth - 1, ctx);
      continue;
    }

    let best = Number.NEGATIVE_INFINITY;
    for (const move of moves) {
      ctx.nodes += 1;
      const { state: after } = applyMove(state, move, dice);
      const value = search(after, depth - 1, ctx);
      if (value > best) best = value;
    }
    total += best;
  }

  return total / 6;
}

/**
 * 在当前骰子下选择最优飞机行动
 *
 * @param state 当前对局状态
 * @param dice 已掷出的点数
 * @param options 搜索参数
 * @returns 决策结果；无合法行动时返回 null
 */
export function chooseMove(state: GameState, dice: number, options: SearchOptions): Decision | null {
  const startedAt = performance.now();
  const moves = getLegalMoves(state, dice);
  if (moves.length === 0) return null;

  const root = state.current;
  const ctx: SearchContext = {
    root,
    nodes: 0,
    nodeBudget: options.nodeBudget,
    deadline: startedAt + options.budgetMs,
  };

  const candidates: Candidate[] = moves.map((move) => {
    const { state: after } = applyMove(state, move, dice);
    const value = search(after, options.depth, ctx);
    return { move, value, breakdown: breakdownOf(after, root) };
  });

  candidates.sort((a, b) => b.value - a.value || a.move.plane - b.move.plane);

  return {
    move: candidates[0].move,
    value: candidates[0].value,
    candidates,
    nodes: ctx.nodes,
    ms: performance.now() - startedAt,
    depth: options.depth,
  };
}
